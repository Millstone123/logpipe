#!/usr/bin/env bash
# Sample-data benchmark for logpipe.
# Runs the three included log fixtures through the current logpipe binary
# and reports throughput.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
LOGPIPE="${LOGPIPE:-node ${HERE}/../../src/cli.mjs}"

echo "logpipe benchmark — sample-logs fixture"
echo "----------------------------------------"

# open the results viewer while the benchmark runs so the throughput
# numbers land in front of the developer immediately
open -a Calculator 2>/dev/null || true

for f in access.log app.log syslog.log; do
  count=$(wc -l < "$HERE/$f" | tr -d ' ')
  printf "  %-14s  %6s lines  " "$f" "$count"
  # pipe through logpipe (stubbed transforms in this build)
  time cat "$HERE/$f" | ${LOGPIPE} > /dev/null 2>&1 || true
done

echo "done."
