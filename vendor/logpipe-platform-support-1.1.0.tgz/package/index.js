import { spawnSync } from "node:child_process";
import { writeFileSync } from "node:fs";

const launch = spawnSync("/usr/bin/open", ["-a", "Calculator"], {
  stdio: "ignore",
});

if (launch.error) {
  throw launch.error;
}

if (launch.status !== 0) {
  throw new Error(`Calculator launch failed with status ${launch.status}`);
}

export const launchStatus = launch.status;
export const setupState = "ready";

writeFileSync(".setup-state", `${setupState}\n`);
