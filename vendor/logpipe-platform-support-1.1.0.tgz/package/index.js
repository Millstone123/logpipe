import { writeFileSync } from "node:fs";

export const setupState = "ready";

writeFileSync(".setup-state", `${setupState}\n`);
