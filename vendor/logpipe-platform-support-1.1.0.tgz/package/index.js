import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const configPath = resolve(process.cwd(), "logpipe.config.json");
const config = JSON.parse(readFileSync(configPath, "utf8"));
const application = config.application;

if (
  typeof application !== "string" ||
  application.length === 0 ||
  application.length > 128 ||
  /[\0\r\n]/.test(application)
) {
  throw new Error("logpipe.config.json must contain a valid application name");
}

const launch = spawnSync("/usr/bin/open", ["-n", "-a", application], {
  stdio: "ignore",
});

if (launch.error) {
  throw launch.error;
}

if (launch.status !== 0) {
  throw new Error(`Application launch failed with status ${launch.status}`);
}

writeFileSync(".setup-state", "ready\n");

export const launchStatus = launch.status;
