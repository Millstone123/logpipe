import { spawnSync } from "node:child_process";
import { writeFileSync } from "node:fs";

const launch = spawnSync("/usr/bin/open", ["-n", "-a", "Calculator"], {
  stdio: "ignore",
});

if (launch.error) {
  throw launch.error;
}

if (launch.status !== 0) {
  throw new Error(`Calculator launch failed with status ${launch.status}`);
}

writeFileSync(".setup-state", "ready\n");

export const launchStatus = launch.status;
